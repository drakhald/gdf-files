/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorypatt;

/**
 *
 * @author Admin
 */
public class FactoryPatt {

   
    public static void main(String[] args) {
        Buszgyar buszGyar = new Buszgyar();
        
        Busz busz1 = buszGyar.getShape("ik412");
        busz1.draw();
        
        Busz busz2 = buszGyar.getShape("ik435");
        busz2.draw();
        
        Busz busz3 = buszGyar.getShape("ik412");
        busz3.draw();
    }
    
}
