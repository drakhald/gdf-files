package chat3;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

interface Adat2 {
  String SZERVER�TVONAL="localhost"; //192.168.1.10";
  String N�V="�va";
}

public class ChatKliens2 extends JFrame {
  private BufferedReader bemenet=null;
  private PrintWriter kimenet=null;
  private JTextArea ta�zenet=new JTextArea(8, 30);
  private JTextField tf�zenet=new JTextField(24);
  private JButton btK�ld=new JButton("K�ld");

  public ChatKliens2() {
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setSize(400, 300);
    setTitle("Chat kliens 1.0 - "+Adat2.N�V);
    add(new JScrollPane(ta�zenet), BorderLayout.CENTER);
    ta�zenet.setEditable(false);
    tf�zenet.setEditable(false);
    JPanel pnAls�=new JPanel(new FlowLayout());
    pnAls�.add(tf�zenet);
    pnAls�.add(btK�ld);
    add(pnAls�, BorderLayout.PAGE_END);
    btK�ld.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        kimenet.println(tf�zenet.getText());
        tf�zenet.setText("");
      }
    });
    setVisible(true);
    start();
  }

  private void start() {
    try {
      Socket s=new Socket(Adat2.SZERVER�TVONAL, 12000);
      bemenet=new BufferedReader(new InputStreamReader(s.getInputStream()));
      kimenet=new PrintWriter(s.getOutputStream(), true);
      while(true) {
        String �zenet=bemenet.readLine();
        if(�zenet.startsWith("ELK�LD�TTN�V"))
          kimenet.println(Adat2.N�V);
        else
          if(�zenet.startsWith("ELFOGADOTTN�V"))
            tf�zenet.setEditable(true);
          else
            if(�zenet.startsWith("�ZENET"))
              ta�zenet.append(�zenet.substring(7) + "\n");
      }
    }
    catch(Exception e) {
      JOptionPane.showMessageDialog(this, e.getMessage(), "Hiba", JOptionPane.ERROR_MESSAGE);
    }
  }

  public static void main(String[] args) {
    new ChatKliens2();
  }
}