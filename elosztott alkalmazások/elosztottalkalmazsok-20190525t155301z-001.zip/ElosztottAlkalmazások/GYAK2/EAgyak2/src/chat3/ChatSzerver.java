package chat3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.TreeSet;

public class ChatSzerver {
  private static final int PORT=12000;
  private static TreeSet<String> bemenetListaFelhaszn�l�=new TreeSet<String>();
  private static ArrayList<PrintWriter> kimenetFolyam�zenet=new ArrayList<PrintWriter>();

  public static void main(String[] args) {
      System.out.println("A chat szerver elindult.");
      ServerSocket ss=null;
      try {
        System.out.println("IP: "+Inet4Address.getLocalHost().getHostAddress());        
        ss=new ServerSocket(PORT);
        while(true)
          new Kezel�(ss.accept()).start();
      }
      catch(IOException e) {
        System.out.println(e.getMessage());
      }
      finally {
        if(ss!=null)
          try {
            ss.close();
          }
          catch(IOException e) {
            System.out.println(e.getMessage());
          }
      }
  }

  static class Kezel� extends Thread {
    private String chatel�N�v;
    private Socket s;
    private BufferedReader bemenet;
    private PrintWriter kimenet;

    public Kezel�(Socket socket) {
      this.s=socket;
    }

    @Override
    public void run() {
      try {
        bemenet=new BufferedReader(new InputStreamReader(s.getInputStream()));
        kimenet=new PrintWriter(s.getOutputStream(), true);
        while(true) {
          kimenet.println("ELK�LD�TTN�V");
          chatel�N�v=bemenet.readLine();
          if(chatel�N�v==null)
            return;
          synchronized(bemenetListaFelhaszn�l�) {
            bemenetListaFelhaszn�l�.add(chatel�N�v);
            break;
          }
        }
        kimenet.println("ELFOGADOTTN�V");
        kimenetFolyam�zenet.add(kimenet);
        while(true) {
          String bemenetiSor=bemenet.readLine();
          if(bemenetiSor==null)
            return;
          for(PrintWriter kimenet�zenet: kimenetFolyam�zenet)
            kimenet�zenet.println("�ZENET " + chatel�N�v + ": " + bemenetiSor);
        }
      }
      catch (IOException e) {
        System.out.println(e.getMessage());
      }
      finally {
        if(chatel�N�v!=null)
          bemenetListaFelhaszn�l�.remove(chatel�N�v);
        if(kimenet!=null) {
          kimenetFolyam�zenet.remove(kimenet);
          try {
            s.close();
          }
          catch(IOException e) {
            System.out.println(e.getMessage());
          }
        }
      }
    }
  }
}