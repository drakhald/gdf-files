package chat1;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class HelloKliens {
  public static void main(String[] args) {
    try {
      System.out.println("Fut a chat-kliens.");
      Socket s=new Socket("localhost", 6898+10);
      System.out.print("�zenet: ");
      String �zenet=new BufferedReader(new InputStreamReader(System.in)).readLine();
      DataOutputStream klienst�l=new DataOutputStream(s.getOutputStream());
      klienst�l.writeBytes(�zenet);
      System.out.println("Kliens k�ldte: "+�zenet);
      s.close();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
}
