package chat2;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.Socket;

public class HelloKliens {
  public static void main(String[] args) {
    try {
      System.out.println("Fut a chat kliens.");
      System.out.println("V�ge: ha �res az �zenet.");
      System.out.print("�zenet: ");
      String �zenet=new BufferedReader(new InputStreamReader(System.in)).readLine();
      while(�zenet.length()>0) {
        Socket s=new Socket("localhost", 6898+10);
        DataOutputStream klienst�l=new DataOutputStream(s.getOutputStream());
        klienst�l.writeBytes(�zenet);
        System.out.println("Kliens k�ldte: "+�zenet);
        s.close();
        System.out.print("�zenet: ");
        �zenet=new BufferedReader(new InputStreamReader(System.in)).readLine();
      }
    }
    catch(ConnectException e) {
      System.out.println("Hiba! Nem fut a HelloSzerver.");
    }
    catch(IOException e) {
      System.out.println("Hiba! Nem siker�lt beolvasni az �zenetet.");
    }
    System.out.println("V�ge.");
  }
}
