package chat2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class HelloSzerver {
  public static void main(String[] args) {
    try {
      System.out.println("Fut a chat szerver.");
      ServerSocket ss=new ServerSocket(6898+10);
      while(true) {
        Socket s=ss.accept();
        BufferedReader klienst�l=new BufferedReader(new InputStreamReader(s.getInputStream()));
        String kliens�zenet=klienst�l.readLine();
        String szerver�zenet="Szerver megkapta: "+kliens�zenet+
          ", szerver v�lasza: "+kliens�zenet.toUpperCase();
        System.out.println(szerver�zenet);
      }
    }
    catch(IOException e) {
      System.out.println("Hiba! Nem siker�lt olvasni a kliens �zenet�t.");
    }
  }
}
