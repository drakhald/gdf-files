/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankdemo;

/**
 *
 * @author Admin
 */
public class BankDemo {

     public static void main(String[] args) {
        Account cust1 = new Account();
        cust1.deposit(500);
        
        Account cust2 = new Account();
        cust2.getBalance();
        
         System.out.print("Cust1-nek van ennyi pénze: ");
         System.out.println(cust1.getBalance());
         
         System.out.print("Cust2-nek van most ennyi pénze: ");
         System.out.println(cust2.getBalance());
    }
    
}
