/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ja.buszgyar;

/**
 *
 * @author Admin
 */
public class Buszgyar {

    public BTip Buszgyar(String nev) {
        BTip busz = null;
        switch (nev) {
            case "ik260": {
                busz = new BIK260();
                return busz;
            }
        }
        switch (nev) {
            case "ik415": {
                busz = new BIK415();
                return busz;
            }
        }
        switch (nev) {
            case "ik435": {
                busz = new BIK435();
                return busz;
            }
        }

        return busz;
    }
}
