/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ja.buszgyar;

/**
 *
 * @author Admin
 */
public class JaBuszgyar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Buszgyar gyar1 = new Buszgyar();

        BTip K1 = gyar1.Buszgyar("ik260");
        K1.busznev();
        BTip K2 = gyar1.Buszgyar("ik435");
        K2.busznev();
        BTip K3 = gyar1.Buszgyar("ik435");
        K3.busznev();
        BTip K4 = gyar1.Buszgyar("ik415");
        K4.busznev();

    }
    
}
