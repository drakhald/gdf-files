/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formfactory;

/**
 *
 * @author Admin
 */
public class ShapeFactory {

    public ISDom ShapeFactory(String tipus) {
        ISDom alakzat = null;
        switch (tipus) {
            case "kor": {
                alakzat = new SKor();
                return alakzat;
            }
            case "hszog": {
                alakzat = new SHszog();
                return alakzat;
            }
            case "negyszog": {
                alakzat = new SNegyszog();
                return alakzat;
            }
        }

        return alakzat;
    }

}
