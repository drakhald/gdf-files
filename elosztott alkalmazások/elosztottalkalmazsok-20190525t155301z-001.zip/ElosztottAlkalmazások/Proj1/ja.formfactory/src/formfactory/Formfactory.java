/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formfactory;

/**
 *
 * @author Admin
 */
public class Formfactory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ShapeFactory gyar1 = new ShapeFactory();

        ISDom kor1 = gyar1.ShapeFactory("kor");
        kor1.szogSzam();

        ISDom kor2 = gyar1.ShapeFactory("kor");
        kor2.szogSzam();

        ISDom hszog1 = gyar1.ShapeFactory("hszog");
        hszog1.szogSzam();

        ISDom nszog1 = gyar1.ShapeFactory("negyFszog");
        nszog1.szogSzam();

        ISDom nszog2 = gyar1.ShapeFactory("negyszog");
        nszog2.szogSzam();
    }

}
