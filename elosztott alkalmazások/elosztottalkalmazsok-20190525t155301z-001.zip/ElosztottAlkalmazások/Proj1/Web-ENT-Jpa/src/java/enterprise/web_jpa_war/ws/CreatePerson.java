

package enterprise.web_jpa_war.ws;

import enterprise.web_jpa_war.entity.Person;
import java.util.List;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
@WebService(serviceName="NameService")
public class CreatePerson {
    public CreatePerson() {}
    
    @PersistenceContext(unitName="EjbComponentPU")
    private EntityManager entityManager; 
    
    public void addPerson(Person person){
        entityManager.persist(person);
    }
    
    @WebMethod(operationName="getPersons")
    public List <Person> getPersons() {
      return entityManager.createQuery("From Person").getResultList();
   }
}
