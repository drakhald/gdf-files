/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package harmadiklabor;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.*;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 *
 * @author janositytimea
 */
public class kockaHang {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        hangLejatszas("https://www.youtube.com/watch?v=o-1U19vao78");
    }
    
    public static void hangLejatszas(String filepath){
        try {
            java.applet.AudioClip clip = java.applet.Applet.newAudioClip(
            new URL(filepath)); clip.play();
        } catch (MalformedURLException murle) { 
            System.out.println(murle);
        }
    }
}
