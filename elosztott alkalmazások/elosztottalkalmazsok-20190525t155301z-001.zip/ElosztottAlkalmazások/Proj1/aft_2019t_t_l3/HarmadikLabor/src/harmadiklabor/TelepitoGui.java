/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package harmadiklabor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 *
 * @author peter.fazekas
 */
public class TelepitoGui {
    JFrame frame;
    JButton installButton;
    
    public TelepitoGui(final InstallerRunnable installer) {
        frame = new JFrame("Telepito");
        frame.setSize(300,300);
        installButton = new JButton("Telepites");

        installButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();
                fc.setCurrentDirectory(new java.io.File(".")); // start at application current directory
                fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int returnVal = fc.showSaveDialog(frame);
                if(returnVal == JFileChooser.APPROVE_OPTION) {
                                installer.setTarget(fc.getSelectedFile().getAbsolutePath());
                                installer.run();
                }
            }
        });
        
        frame.add(installButton);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
}
