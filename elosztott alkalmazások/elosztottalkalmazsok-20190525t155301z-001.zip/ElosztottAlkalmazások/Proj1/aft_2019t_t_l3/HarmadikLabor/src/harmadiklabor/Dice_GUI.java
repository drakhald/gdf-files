/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package harmadiklabor;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class Dice_GUI  extends JFrame{
    private JFrame jf = new JFrame();
    private JPanel pane = new JPanel();
    private JSpinner jsDb = new JSpinner(new SpinnerNumberModel(1,1,50,1));
    private JSpinner jsOldal = new JSpinner(new SpinnerNumberModel(1,1,50,1));
    private  JButton dob_btn = new JButton("Dobj!");
    public Dice_GUI(){
        jf.setVisible(true);
        jf.setSize(450, 450);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        jf.add(pane);
        pane.setLayout(null);
        JLabel db_lb = new JLabel("Dobások száma: ");
        JLabel oldal_lb = new JLabel("Oldalak száma: ");
        db_lb.setBounds(50, 100, 150, 20);
        oldal_lb.setBounds(50, 180, 150, 20);
        jsDb.setBounds(250, 100, 50, 20);
        jsOldal.setBounds(250, 180, 50, 20);
        dob_btn.setBounds(180, 250, 80, 20);
        pane.add(jsDb);
        pane.add(jsOldal);
        pane.add(db_lb);
        pane.add(oldal_lb);
        pane.add(dob_btn);
        
    }
    public static void main(String[] args) {
        Dice_GUI dg = new Dice_GUI();
    }
}
