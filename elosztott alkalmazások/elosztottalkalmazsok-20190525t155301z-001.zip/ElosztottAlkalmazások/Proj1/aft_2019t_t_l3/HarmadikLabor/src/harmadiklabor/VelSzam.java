/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package harmadiklabor;

import java.util.Random;

/**
 *
 * @author Jónás Attila
 */
public class VelSzam {

   private static int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            throw new UnsupportedOperationException("Még nincs támogatva..."); //To change body of generated methods, choose Tools | Templates.
        }
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
   
   public String kockadobasok(int darab, int meret, int varakozas) {
       String eredmenyStr = "";
       int osszeg = 0;
       for (int i=0;i<darab;i++) {
            int eredmeny = getRandomNumberInRange(1,meret);
            osszeg = osszeg + eredmeny;
            try {
               Thread.sleep(varakozas);   
            } catch (Exception e) {
                 System.out.println("Vmi nem jó... a Thread Sleep-pel");
            }
       }
       eredmenyStr = eredmenyStr + " ,Dobások összege: " + osszeg;
       return eredmenyStr;
   }
   
}
