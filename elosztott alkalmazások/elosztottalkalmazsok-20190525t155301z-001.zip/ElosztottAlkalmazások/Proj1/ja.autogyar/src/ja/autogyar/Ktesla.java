/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ja.autogyar;

/**
 *
 * @author Admin
 */
public class Ktesla implements IATipus { 
    @Override
    public void autoNeve() {
        System.out.println("Tesla 3");
    }

}
