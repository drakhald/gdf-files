/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ja.autogyar;

/**
 *
 * @author Admin
 */
public class Autogyar {

    public IATipus Autogyar(String nev) {
        IATipus auto = null;
        switch (nev) {
            case "hon": {
                auto = new Khonda();
                return auto;
            }
        }
        switch (nev) {
            case "tes": {
                auto = new Ktesla();
                return auto;
            }
        }
        switch (nev) {
            case "wv": {
                auto = new Kwv();
                return auto;
            }
        }

        return auto;
    }
}
