/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ja.autogyar;

/**
 *
 * @author Admin
 */
public class JaAutogyar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Autogyar gyar1 = new Autogyar();

        IATipus K1 = gyar1.Autogyar("hon");
        K1.autoNeve();
        IATipus K2 = gyar1.Autogyar("hon");
        K2.autoNeve();
        IATipus K3 = gyar1.Autogyar("tes");
        K3.autoNeve();

    }

}
