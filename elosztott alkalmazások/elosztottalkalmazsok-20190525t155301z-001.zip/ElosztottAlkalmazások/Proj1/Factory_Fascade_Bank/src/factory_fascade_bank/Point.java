/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factory_fascade_bank;

/**
 *
 * @author hallgato
 */
public class Point {
    private float[] p=new float[2];
    
    public Point(float x, float y){
        setXY(x,y);
    }
    
    public Point(){
    }
    
    public void setX(float x){
        p[0]=x;
    }
    
    public void setY(float y){
        p[1]=y;
    }
    
    public void setXY(float x, float y){
        p[0]=x;
        p[1]=y;
    }
    
    public float getX(){
        return p[0];
    }
    
    public float getY(){
        return p[1];
    }
}
