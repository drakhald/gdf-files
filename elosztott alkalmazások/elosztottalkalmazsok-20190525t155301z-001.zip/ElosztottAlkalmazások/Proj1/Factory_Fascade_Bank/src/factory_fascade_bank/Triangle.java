/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factory_fascade_bank;
import java.lang.Math;

/**
 *
 * @author hallgato
 */
public class Triangle extends Polygon implements Shape{
    
    private Point p1=new Point();
    private Point p2=new Point();
    private Point p3=new Point();
    
    public Triangle(float p1x, float p1y, float p2x, float p2y, float p3x, float p3y){
        p1.setXY(p1x, p1y);
        p2.setXY(p2x, p2y);
        p3.setXY(p3x, p3y);
    }
    
    @Override
    public float area() {
        float A;
        A=      p1.getX()*(p2.getY()-p3.getY())
                +p2.getX()*(p3.getY()-p1.getY())
                +p3.getX()*(p1.getY()-p2.getY());
        A/=2;
        A=Math.abs(A);
        System.out.println(p1.getX());
        System.out.println(p1.getY());
        return A;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
