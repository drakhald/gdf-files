/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factory_fascade_bank;

import java.util.Scanner;

/**
 *
 * @author hallgato
 */
public class ShapeFactory {
    Scanner in = new Scanner(System.in);
    private float[] p;
    String shapeType;
    
    public Polygon makeShape(){
        System.out.println("Choose a polygon type:");
        
        shapeType=in.nextLine();
        
        if(shapeType.equalsIgnoreCase("Triangle")){
            p=new float[6];
            
            for(int i=0; i<6; i++){
                System.out.println("Enter coordinate:");
                p[i]=in.nextFloat();
            }
            System.out.println("Triangle successfully created.");
            return new Triangle(p[0],p[1],p[2],p[3],p[4],p[5]);
        }
    return null;
    }
}
