/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmitutorial;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


/**
 *
 * @author dev
 */
public class RMIClient {
    
    private void doTest(){
        try {
            // fire to localhost port 1099
            Registry myRegistry = LocateRegistry.getRegistry("192.168.81.52", 1099);
             
            // search for myMessage service
            Message impl = (Message) myRegistry.lookup("myMessage");
             
            // call server's method        
            impl.sayHello("Béla a Lenovoról");
             
            System.out.println("Message Sent");
        } catch (Exception e) {
            e.printStackTrace();
        }       
    }
     
    public static void main(String[] args) {
        RMIClient main = new RMIClient();
        main.doTest();
    }
}
    

